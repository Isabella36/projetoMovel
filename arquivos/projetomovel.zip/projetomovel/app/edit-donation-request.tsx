import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  TextInput, 
  TouchableOpacity, 
  StyleSheet, 
  SafeAreaView,
  ScrollView,
  Alert,
  KeyboardAvoidingView,
  Platform
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { useDonation } from '@/contexts/DonationContext';

interface DonationRequest {
  title: string;
  description: string;
  category: string;
  deadline: string;
  quantity: string;
  contact: string;
  location: string;
}

export default function EditDonationRequestScreen() {
  const { donationRequests, updateDonationRequest } = useDonation();
  const { id } = useLocalSearchParams();
  
  const donationRequest = donationRequests.find(req => req.id === id);
  
  const [formData, setFormData] = useState<DonationRequest>({
    title: '',
    description: '',
    category: '',
    deadline: '',
    quantity: '',
    contact: '',
    location: ''
  });

  useEffect(() => {
    if (donationRequest) {
      setFormData({
        title: donationRequest.title,
        description: donationRequest.description,
        category: donationRequest.category,
        deadline: donationRequest.deadline,
        quantity: donationRequest.quantity || '',
        contact: donationRequest.contact,
        location: donationRequest.city
      });
    }
  }, [donationRequest]);

  if (!donationRequest) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.errorContainer}>
          <Text style={styles.errorText}>Pedido não encontrado</Text>
          <TouchableOpacity 
            style={styles.backButton}
            onPress={() => router.back()}
          >
            <Text style={styles.backButtonText}>Voltar</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  const categories = ['Roupas', 'Alimentos', 'Higiene', 'Medicamentos', 'Livros', 'Brinquedos'];

  const handleInputChange = (field: keyof DonationRequest, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleCategorySelect = (category: string) => {
    setFormData(prev => ({
      ...prev,
      category
    }));
  };

  const handleSave = () => {
    if (!formData.title || !formData.description || !formData.category || !formData.deadline || !formData.contact || !formData.location) {
      Alert.alert('Erro', 'Por favor, preencha todos os campos obrigatórios');
      return;
    }

    // Atualiza o pedido existente
    updateDonationRequest(id as string, {
      title: formData.title,
      description: formData.description,
      category: formData.category,
      city: formData.location,
      deadline: formData.deadline,
      contact: formData.contact,
      quantity: formData.quantity || undefined,
    });

    Alert.alert(
      'Sucesso',
      'Campanha atualizada com sucesso!',
      [
        { 
          text: 'OK', 
          onPress: () => router.push('/donation-requests') 
        }
      ]
    );
  };

  const formatDate = (text: string) => {
    const numbers = text.replace(/\D/g, '');
    
    if (numbers.length <= 2) {
      return numbers;
    } else if (numbers.length <= 4) {
      return `${numbers.slice(0, 2)}/${numbers.slice(2)}`;
    } else {
      return `${numbers.slice(0, 2)}/${numbers.slice(2, 4)}/${numbers.slice(4, 8)}`;
    }
  };

  const formatPhone = (text: string) => {
    const numbers = text.replace(/\D/g, '');
    
    if (numbers.length <= 2) {
      return numbers;
    } else if (numbers.length <= 7) {
      return `(${numbers.slice(0, 2)}) ${numbers.slice(2)}`;
    } else {
      return `(${numbers.slice(0, 2)}) ${numbers.slice(2, 7)}-${numbers.slice(7, 11)}`;
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <KeyboardAvoidingView 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.keyboardView}
      >
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <Ionicons name="arrow-back" size={24} color="#333" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Editar campanha</Text>
          <View style={styles.placeholder} />
        </View>

        <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
          {/* Form Fields */}
          <View style={styles.formContainer}>
            <Text style={styles.label}>Título do pedido</Text>
            <TextInput
              style={styles.input}
              placeholder="Digite o título do pedido"
              value={formData.title}
              onChangeText={(value) => handleInputChange('title', value)}
            />

            <Text style={styles.label}>Descrição</Text>
            <TextInput
              style={[styles.input, styles.textArea]}
              placeholder="Descreva o que você precisa"
              value={formData.description}
              onChangeText={(value) => handleInputChange('description', value)}
              multiline
              numberOfLines={4}
              textAlignVertical="top"
            />

            <Text style={styles.label}>Categoria *</Text>
            <View style={styles.categoryContainer}>
              {categories.map((category) => (
                <TouchableOpacity
                  key={category}
                  style={[
                    styles.categoryButton,
                    formData.category === category && styles.categoryButtonSelected
                  ]}
                  onPress={() => handleCategorySelect(category)}
                >
                  <Text style={[
                    styles.categoryButtonText,
                    formData.category === category && styles.categoryButtonTextSelected
                  ]}>
                    {category}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>

            <View style={styles.rowContainer}>
              <View style={styles.halfWidth}>
                <Text style={styles.label}>Prazo</Text>
                <TextInput
                  style={styles.input}
                  placeholder="DD/MM/AAAA"
                  value={formData.deadline}
                  onChangeText={(value) => handleInputChange('deadline', formatDate(value))}
                  maxLength={10}
                  keyboardType="numeric"
                />
              </View>
              
              <View style={styles.halfWidth}>
                <Text style={styles.label}>Quantidade (opcional)</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Ex: 50"
                  value={formData.quantity}
                  onChangeText={(value) => handleInputChange('quantity', value)}
                  keyboardType="numeric"
                />
              </View>
            </View>

            <Text style={styles.label}>Contato</Text>
            <TextInput
              style={styles.input}
              placeholder="(XX) XXXXX-XXXX"
              value={formData.contact}
              onChangeText={(value) => handleInputChange('contact', formatPhone(value))}
              keyboardType="phone-pad"
              maxLength={15}
            />

            <Text style={styles.label}>Local</Text>
            <TextInput
              style={styles.input}
              placeholder="Digite a cidade"
              value={formData.location}
              onChangeText={(value) => handleInputChange('location', value)}
            />
          </View>

          {/* Preview Section */}
          <View style={styles.previewContainer}>
            <Text style={styles.previewTitle}>Pré-visualização</Text>
            <View style={styles.previewCard}>
              <Text style={styles.previewCardTitle}>
                {formData.title || 'Título do pedido'}
              </Text>
              <Text style={styles.previewCardInfo}>
                {formData.category || 'Categoria'} · Até {formData.deadline || 'DD/MM/AAAA'}
              </Text>
              <Text style={styles.previewCardLocation}>
                {formData.location || 'Cidade'}
              </Text>
            </View>
          </View>

          {/* Save Button */}
          <TouchableOpacity style={styles.saveButton} onPress={handleSave}>
            <Text style={styles.saveButtonText}>Salvar alterações</Text>
          </TouchableOpacity>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  keyboardView: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 32,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  backButton: {
    padding: 8,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
  },
  placeholder: {
    width: 40,
  },
  content: {
    flex: 1,
  },
  formContainer: {
    backgroundColor: '#fff',
    margin: 16,
    padding: 20,
    borderRadius: 12,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 8,
    marginTop: 16,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 16,
    backgroundColor: '#fff',
  },
  textArea: {
    height: 100,
    textAlignVertical: 'top',
  },
  categoryContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: 16,
  },
  categoryButton: {
    borderWidth: 1,
    borderColor: '#007AFF',
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 8,
    marginRight: 8,
    marginBottom: 8,
    backgroundColor: '#fff',
  },
  categoryButtonSelected: {
    backgroundColor: '#007AFF',
  },
  categoryButtonText: {
    color: '#007AFF',
    fontSize: 14,
    fontWeight: '500',
  },
  categoryButtonTextSelected: {
    color: '#fff',
  },
  rowContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  halfWidth: {
    flex: 1,
    marginRight: 8,
  },
  previewContainer: {
    margin: 16,
  },
  previewTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 12,
  },
  previewCard: {
    backgroundColor: '#f8f9fa',
    padding: 16,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#e9ecef',
  },
  previewCardTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 8,
  },
  previewCardInfo: {
    fontSize: 14,
    color: '#666',
    marginBottom: 4,
  },
  previewCardLocation: {
    fontSize: 14,
    color: '#666',
  },
  saveButton: {
    backgroundColor: '#28a745',
    borderRadius: 8,
    paddingVertical: 16,
    margin: 16,
    alignItems: 'center',
  },
  saveButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  errorText: {
    fontSize: 18,
    color: '#666',
    marginBottom: 20,
  },
  backButtonText: {
    color: '#dc3545',
    fontSize: 16,
    fontWeight: '600',
  },
});
