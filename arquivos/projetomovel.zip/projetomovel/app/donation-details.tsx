import React from 'react';
import { 
  View, 
  Text, 
  TouchableOpacity, 
  StyleSheet, 
  SafeAreaView,
  ScrollView,
  Image,
  Alert
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { useDonation } from '@/contexts/DonationContext';

export default function DonationDetailsScreen() {
  const { donationRequests } = useDonation();
  const { id } = useLocalSearchParams();
  
  const donationRequest = donationRequests.find(req => req.id === id);

  if (!donationRequest) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.errorContainer}>
          <Text style={styles.errorText}>Pedido não encontrado</Text>
          <TouchableOpacity 
            style={styles.backButton}
            onPress={() => router.back()}
          >
            <Text style={styles.backButtonText}>Voltar</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  const handleDonate = () => {
    Alert.alert(
      'Doação',
      `Entre em contato com ${donationRequest.contact} para realizar sua doação.`,
      [
        { text: 'OK' }
      ]
    );
  };

  const handleEdit = () => {
    router.push(`/edit-donation-request?id=${donationRequest.id}`);
  };

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <Ionicons name="arrow-back" size={24} color="#333" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Detalhes</Text>
        <TouchableOpacity onPress={handleEdit} style={styles.editButton}>
          <Ionicons name="create-outline" size={24} color="#333" />
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Image */}
        <View style={styles.imageContainer}>
          <Image 
            source={donationRequest.imageUri ? { uri: donationRequest.imageUri } : require("@/assets/images/logo2.jpeg")}
            style={styles.campaignImage}
            resizeMode="cover"
          />
        </View>

        {/* Content */}
        <View style={styles.detailsContainer}>
          <Text style={styles.title}>{donationRequest.title}</Text>
          
          <Text style={styles.description}>
            {donationRequest.description}
          </Text>

          <View style={styles.infoSection}>
            <Text style={styles.infoLabel}>Categoria</Text>
            <View style={styles.categoryTag}>
              <Text style={styles.categoryText}>{donationRequest.category}</Text>
            </View>
          </View>

          <View style={styles.infoSection}>
            <Text style={styles.infoLabel}>Prazo</Text>
            <Text style={styles.infoValue}>Até {donationRequest.deadline}</Text>
          </View>

          <View style={styles.infoSection}>
            <Text style={styles.infoLabel}>Contato</Text>
            <Text style={styles.infoValue}>{donationRequest.contact}</Text>
          </View>

          {donationRequest.quantity && (
            <View style={styles.infoSection}>
              <Text style={styles.infoLabel}>Quantidade</Text>
              <Text style={styles.infoValue}>{donationRequest.quantity} itens</Text>
            </View>
          )}

          <View style={styles.infoSection}>
            <Text style={styles.infoLabel}>Local</Text>
            <Text style={styles.infoValue}>{donationRequest.city}</Text>
          </View>
        </View>
      </ScrollView>

      {/* Fixed Donate Button */}
      <View style={styles.fixedButtonContainer}>
        <TouchableOpacity style={styles.donateButton} onPress={handleDonate}>
          <Text style={styles.donateButtonText}>Doar</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 30,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  backButton: {
    
    
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
    
  },
  editButton: {
    paddingTop: 10,
  },
  content: {
    flex: 1,
  },
  imageContainer: {
    width: '100%',
    height: 250,
  },
  campaignImage: {
    width: '100%',
    height: '100%',
  },
  detailsContainer: {
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 16,
    lineHeight: 30,
  },
  description: {
    fontSize: 16,
    color: '#333',
    lineHeight: 24,
    marginBottom: 24,
  },
  infoSection: {
    marginBottom: 20,
  },
  infoLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 8,
  },
  infoValue: {
    fontSize: 16,
    color: '#333',
  },
  categoryTag: {
    backgroundColor: '#f0f0f0',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    alignSelf: 'flex-start',
  },
  categoryText: {
    fontSize: 14,
    color: '#333',
    fontWeight: '500',
  },
  fixedButtonContainer: {
    backgroundColor: '#fff',
    paddingHorizontal: 20,
    paddingVertical: 35,
    borderTopWidth: 1,
    borderTopColor: '#e0e0e0',
  },
  donateButton: {
    backgroundColor: '#dc3545',
    borderRadius: 8,
    paddingVertical: 16,
    alignItems: 'center',
  },
  donateButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  errorText: {
    fontSize: 18,
    color: '#666',
    marginBottom: 20,
  },
  backButtonText: {
    color: '#dc3545',
    fontSize: 16,
    fontWeight: '600',
  },
});
