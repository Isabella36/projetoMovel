import React, { useState } from 'react';
import { 
  View, 
  Text, 
  TouchableOpacity, 
  StyleSheet, 
  SafeAreaView,
  ScrollView,
  Alert,
  Modal
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useDonation, DonationRequest } from '@/contexts/DonationContext';

export default function DonationRequestsScreen() {
  const { donationRequests, deleteDonationRequest } = useDonation();
  const [showMenu, setShowMenu] = useState(false);

  const handleViewDetails = (request: DonationRequest) => {
    router.push(`/donation-details?id=${request.id}`);
  };

  const handleCreateProject = () => {
    router.push('/new-donation-request');
  };

  const handleLogout = () => {
    Alert.alert(
      'Sair',
      'Tem certeza que deseja sair?',
      [
        { text: 'Cancelar', style: 'cancel' },
        { text: 'Sair', onPress: () => router.push('/(tabs)') }
      ]
    );
  };

  const handleDeleteCampaigns = () => {
    Alert.alert(
      'Deletar Campanhas',
      'Tem certeza que deseja deletar todas as suas campanhas? Esta ação não pode ser desfeita.',
      [
        { text: 'Cancelar', style: 'cancel' },
        { 
          text: 'Deletar', 
          style: 'destructive',
          onPress: () => {
            // Deleta todas as campanhas (exceto as padrões)
            donationRequests.forEach(request => {
              if (!['1', '2', '3'].includes(request.id)) {
                deleteDonationRequest(request.id);
              }
            });
            Alert.alert('Sucesso', 'Suas campanhas foram deletadas com sucesso!');
          }
        }
      ]
    );
    setShowMenu(false);
  };

  const handleEditCampaigns = () => {
    Alert.alert(
      'Editar Campanhas',
      'Para editar uma campanha, acesse os detalhes da campanha desejada e use a opção de edição.',
      [{ text: 'OK' }]
    );
    setShowMenu(false);
  };

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={handleLogout} style={styles.backButton}>
          <Ionicons name="arrow-back" size={24} color="#fff" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Pedidos de Doação</Text>
        <TouchableOpacity 
          style={styles.menuButton}
          onPress={() => setShowMenu(true)}
        >
          <Ionicons name="menu" size={24} color="#fff" />
        </TouchableOpacity>
      </View>

      {/* Content */}
      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {donationRequests.map((request) => (
          <View key={request.id} style={styles.card}>
            <View style={styles.cardHeader}>
              <Text style={styles.cardTitle}>{request.title}</Text>
              <View style={styles.statusTag}>
                <Text style={styles.statusText}>{request.status}</Text>
              </View>
            </View>
            
            <Text style={styles.cardInfo}>
              {request.category} • {request.city}
            </Text>
            
            <Text style={styles.cardDeadline}>
              Até {request.deadline}
            </Text>
            
            <Text style={styles.cardDescription}>
              {request.description}
            </Text>
            
            <TouchableOpacity 
              style={styles.detailsButton}
              onPress={() => handleViewDetails(request)}
            >
              <Text style={styles.detailsButtonText}>Ver detalhes</Text>
            </TouchableOpacity>
          </View>
        ))}
        
        {/* Spacer for fixed button */}
        <View style={styles.spacer} />
      </ScrollView>

      {/* Fixed Create Project Button */}
      <View style={styles.fixedButtonContainer}>
        <TouchableOpacity style={styles.createButton} onPress={handleCreateProject}>
          <Text style={styles.createButtonText}>Cadastrar projeto</Text>
        </TouchableOpacity>
      </View>

      {/* Menu Modal */}
      <Modal
        visible={showMenu}
        transparent={true}
        animationType="fade"
        onRequestClose={() => setShowMenu(false)}
      >
        <TouchableOpacity 
          style={styles.modalOverlay}
          activeOpacity={1}
          onPress={() => setShowMenu(false)}
        >
          <View style={styles.menuContainer}>
            <TouchableOpacity 
              style={styles.menuItem}
              onPress={handleEditCampaigns}
            >
              <Ionicons name="create-outline" size={24} color="#333" />
              <Text style={styles.menuItemText}>Editar Campanhas</Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.menuItem}
              onPress={handleDeleteCampaigns}
            >
              <Ionicons name="trash-outline" size={24} color="#dc3545" />
              <Text style={[styles.menuItemText, { color: '#dc3545' }]}>Deletar Campanhas</Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.menuItem}
              onPress={handleLogout}
            >
              <Ionicons name="log-out-outline" size={24} color="#333" />
              <Text style={styles.menuItemText}>Sair</Text>
            </TouchableOpacity>
          </View>
        </TouchableOpacity>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    backgroundColor: '#dc3545',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 30,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
  },
  backButton: {
    padding: 8,
  },
  headerTitle: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  menuButton: {
    padding: 8,
  },
  content: {
    flex: 1,
    paddingHorizontal: 16,
    paddingTop: 20,
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 8,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    flex: 1,
    marginRight: 8,
  },
  statusTag: {
    backgroundColor: '#28a745',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  statusText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '600',
  },
  cardInfo: {
    fontSize: 14,
    color: '#666',
    marginBottom: 4,
  },
  cardDeadline: {
    fontSize: 14,
    color: '#666',
    marginBottom: 8,
  },
  cardDescription: {
    fontSize: 14,
    color: '#333',
    marginBottom: 12,
    lineHeight: 20,
  },
  detailsButton: {
    alignSelf: 'flex-end',
  },
  detailsButtonText: {
    color: '#dc3545',
    fontSize: 14,
    fontWeight: '600',
    textDecorationLine: 'underline',
  },
  spacer: {
    height: 100,
  },
  fixedButtonContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: '#fff',
    paddingHorizontal: 16,
    paddingVertical: 40,
    borderTopWidth: 1,
    borderTopColor: '#e0e0e0',
  },
  createButton: {
    backgroundColor: '#dc3545',
    borderRadius: 8,
    paddingVertical: 16,
    alignItems: 'center',
  },
  createButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  menuContainer: {
    backgroundColor: '#fff',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingVertical: 20,
    paddingHorizontal: 20,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 16,
    paddingHorizontal: 16,
    borderRadius: 8,
    marginBottom: 8,
  },
  menuItemText: {
    fontSize: 16,
    color: '#333',
    marginLeft: 16,
    fontWeight: '500',
  },
});
