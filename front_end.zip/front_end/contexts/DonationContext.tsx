import React, { createContext, useContext, useState, ReactNode } from 'react';

export interface DonationRequest {
  id: string;
  title: string;
  category: string;
  city: string;
  deadline: string;
  description: string;
  status: 'ABERTO' | 'FECHADO';
  quantity?: string;
  contact: string;
  imageUri?: string;
}

interface DonationContextType {
  donationRequests: DonationRequest[];
  addDonationRequest: (request: Omit<DonationRequest, 'id'>) => void;
  deleteDonationRequest: (id: string) => void;
  updateDonationRequest: (id: string, request: Partial<DonationRequest>) => void;
}

const DonationContext = createContext<DonationContextType | undefined>(undefined);

export const useDonation = () => {
  const context = useContext(DonationContext);
  if (!context) {
    throw new Error('useDonation must be used within a DonationProvider');
  }
  return context;
};

interface DonationProviderProps {
  children: ReactNode;
}

export const DonationProvider: React.FC<DonationProviderProps> = ({ children }) => {
  const [donationRequests, setDonationRequests] = useState<DonationRequest[]>([
    {
      id: '1',
      title: 'Campanha do Agasalho 2025',
      category: 'Roupas',
      city: 'São Paulo',
      deadline: '30/06/2025',
      description: 'Roupas infantis para famílias da comunidade...',
      status: 'ABERTO',
      contact: '(11) 98765-4321',
      imageUri: 'https://via.placeholder.com/150/FF0000/FFFFFF?text=Roupas', // Exemplo de imagem
    },
    {
      id: '2',
      title: 'Cestas Básicas Urgente',
      category: 'Alimentos',
      city: 'Belo Horizonte',
      deadline: '15/05/2025',
      description: 'Ajude com alimentos não perecíveis para...',
      status: 'ABERTO',
      contact: '(31) 99999-8888',
      imageUri: 'https://via.placeholder.com/150/00FF00/FFFFFF?text=Alimentos', // Exemplo de imagem
    },
    {
      id: '3',
      title: 'Kits de Higiene para Abrigo',
      category: 'Higiene',
      city: 'Curitiba',
      deadline: '20/04/2025',
      description: 'Necessitamos de sabonetes, shampoos e itens...',
      status: 'ABERTO',
      contact: '(41) 88888-7777',
      imageUri: 'https://via.placeholder.com/150/0000FF/FFFFFF?text=Higiene', // Exemplo de imagem
    }
  ]);

  const addDonationRequest = (request: Omit<DonationRequest, 'id'>) => {
    const newRequest: DonationRequest = {
      ...request,
      id: Date.now().toString(),
    };
    setDonationRequests(prev => [newRequest, ...prev]);
  };

  const deleteDonationRequest = (id: string) => {
    setDonationRequests(prev => prev.filter(request => request.id !== id));
  };

  const updateDonationRequest = (id: string, updatedRequest: Partial<DonationRequest>) => {
    setDonationRequests(prev => 
      prev.map(request => 
        request.id === id 
          ? { ...request, ...updatedRequest }
          : request
      )
    );
  };

  return (
    <DonationContext.Provider value={{ 
      donationRequests, 
      addDonationRequest, 
      deleteDonationRequest, 
      updateDonationRequest 
    }}>
      {children}
    </DonationContext.Provider>
  );
};
